import { chooseAlbumListener } from './listeners.js';

debugger;

chooseAlbumListener();
