export const ORIGIN = 'https://jsonplaceholder.typicode.com';
